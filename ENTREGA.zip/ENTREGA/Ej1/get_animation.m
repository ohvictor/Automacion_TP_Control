function [outputArg1,outputArg2] = get_animation(name,t,q_in, T_in, q_out, T_out)
%get_animation Generar animacion del robot
%   Detailed explanation goes here

    

end

